CREATE table users (
	id int(10) not null AUTO_INCREMENT PRIMARY key,
    first varchar(128) not null,
   last varchar(128) not null,
    usr varchar(128) not null,
    pwd varchar(128) not null
    
);