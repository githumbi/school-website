<?php
session_start();
include 'dbh.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Bootstrap Simple Login Form</title>
<link rel="stylesheet" href="style/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="style/bootstrap.min.js"></script> 
<link rel="stylesheet" href="style/custom.css">
</head>
<body>
<header>
<nav>
<ul>
<li><a href="index.php">home</a></li>
<li><a href="signup.php">Signup</a></li>
</ul>
</nav>
</header>